# Simple To-Do List — Beginner's Code and Viva Guide

This guide explains the app from the beginning and gives you a demonstration plan and viva answers. Keep `index.html`, `style.css` and `script.js` open in VS Code while reading.

## 1. Project overview

My project is a simple To-Do List web application. A user can add a task, mark it complete, delete it, filter the list, and clear completed tasks. It uses:

- **HTML** for the structure: input, buttons, list and headings.
- **CSS** for styling: layout, colours, spacing, completed-task appearance and mobile layout.
- **JavaScript** for logic: creating, updating, filtering and deleting tasks.
- **localStorage** to remember tasks in the same browser after a refresh.

This is a frontend project. It has no backend server and no remote database.

### The main flow
1. User types a task and presses Add task.
2. JavaScript reads the input and removes extra spaces using `.trim()`.
3. It creates a task object and adds it to the `tasks` array.
4. It stores the array in browser localStorage as JSON.
5. `renderTasks()` rebuilds the visible task list.
6. The user can check a task, delete it, or change the filter.
7. On refresh, `loadTasks()` reads the saved list back into JavaScript.

Remember this: **update the data → save it → render the page again**.

## 2. Run and demonstrate it

1. Extract the ZIP.
2. Open `SimpleTodoApp` in VS Code.
3. Open `index.html` in a browser, or right-click it and select Open with Live Server.
4. Add three tasks such as “Read notes”, “Practise viva”, and “Submit report”.
5. Mark one as complete.
6. Click All, Active and Completed.
7. Refresh the browser to show that tasks remain saved.
8. Delete a task and try Clear completed.

If tasks do not persist, check whether browser storage is enabled. Private browsing modes or clearing site data may remove local data.

## 3. HTML explained

Open `index.html`.

### Document setup
`<!DOCTYPE html>` tells the browser to use modern HTML standards. `<html lang="en">` is the root element and identifies English as the page language.

The `<head>` contains metadata and linked files. `charset="UTF-8"` supports common character sets. The viewport meta tag helps the app fit mobile screens. `<title>` sets the browser tab title. `<link rel="stylesheet" href="style.css">` loads the CSS file.

### Body and semantic structure
The body has a header, a task section, a form, a filter navigation area, a list, status messages and a footer.

`<form id="task-form">` groups the new-task input and Add task button. Listening to a form's `submit` event works when the user clicks the button or presses Enter.

`<input id="task-input" type="text" ...>` lets the user type a task. The `id` is a unique name JavaScript can use to locate this element. `placeholder` shows a hint, `maxlength` limits the length, and `required` asks the browser to require a value for normal submission.

`<ul id="task-list"></ul>` is an empty unordered list at first. JavaScript creates `<li>` elements for the visible tasks.

### IDs and classes
An ID, such as `task-list`, identifies a specific element. A class, such as `task-item`, can be reused on many task rows. JavaScript commonly selects elements by ID; CSS commonly styles elements by class.

The app uses labels and accessible status attributes. The visually hidden label for the input is still available to screen readers. `aria-live="polite"` helps assistive technology announce status updates.

## 4. CSS explained

Open `style.css`.

A CSS rule like this:

```css
.primary-button {
  background: var(--blue);
  color: white;
  border-radius: 9px;
}
```

selects elements with the class `primary-button` and sets their appearance. A dot selects a class; a hash selects an ID.

### Variables, space and layout
The `:root` section defines reusable variables such as `--blue`, `--ink` and `--line`. They are used through `var(--blue)`. This makes it easy to change a colour consistently.

`box-sizing: border-box` makes an element's width include its padding and border. **Padding** is space inside the border; **margin** is space outside it.

The add form uses Flexbox: `display: flex` arranges the input and button in a row, while `gap` sets the space between them. A media query changes the form into a column on narrow screens.

### Responsive design and visual states
The rule inside `@media (max-width: 480px)` applies on small viewports. That makes the app easier to use on a phone. The `.completed` class crosses out completed task text. JavaScript assigns the class; CSS decides what it looks like. The selected filter uses the `.active` class.

The interface intentionally uses a simple white card, a light background and one blue accent colour. Styling makes the app readable without adding distracting decoration.

## 5. JavaScript explained

Open `script.js` and follow its sections in order.

### A. Finding HTML elements

```javascript
const taskForm = document.querySelector("#task-form");
const taskInput = document.querySelector("#task-input");
```

`document` represents the current webpage. `querySelector()` returns the first element that matches a CSS selector. `#task-form` means the element with that ID. `const` declares a binding that cannot be reassigned, though the referenced HTML element can still be changed.

### B. Loading and saving

```javascript
const STORAGE_KEY = "simple-todo-tasks-v1";
let tasks = loadTasks();
```

The storage key is the name used to find the saved data. `tasks` is declared with `let` because the array can be reassigned when tasks are deleted or cleared.

`localStorage.getItem()` reads a value saved by the browser. Local storage values are strings, so `JSON.parse()` converts the saved JSON string back into a JavaScript value. If nothing was saved, the ternary expression `savedTasks ? JSON.parse(savedTasks) : []` returns an empty array.

`JSON.stringify(tasks)` converts the array into a JSON string; `localStorage.setItem()` stores it. The `try...catch` in `loadTasks()` prevents badly formatted saved data from crashing the whole app.

**Local storage is not a cloud database.** It saves data for this site in this browser. It does not automatically sync to other devices, and clearing browser data can remove it.

### C. What is a task object?

Each task looks like this:

```javascript
{ id: "unique-id", text: "Practise viva", completed: false }
```

An **object** groups related properties. `id` identifies the task, `text` is its name, and `completed` is a Boolean (`true` or `false`). The `tasks` array contains many task objects.

### D. Filters

`currentFilter` stores which filter the user selected. `getVisibleTasks()` uses `filter()` to return matching tasks:

- Active: `!task.completed` means the task is not completed.
- Completed: `task.completed` is true.
- All: return the full array.

Filtering only changes what's visible; it does not delete hidden tasks.

### E. Rendering the list

`renderTasks()` first uses `taskList.replaceChildren()` to clear the previous displayed rows. It then loops through the visible tasks using `forEach()` and creates a list item, checkbox, task-text span and Delete button with `document.createElement()`.

The code uses `text.textContent = task.text` to display the user's text. `textContent` inserts plain text rather than interpreting it as HTML, which is safer for user-entered content. The created elements are joined with `append()` and inserted in the task list.

The active-task count is calculated by filtering out completed tasks and checking `.length`. If there are no visible tasks, an empty-state message is shown.

### F. Adding a task

The code listens for the form's `submit` event. `event.preventDefault()` prevents the browser's default form behaviour from reloading the page. `taskInput.value` reads the text; `.trim()` removes spaces at the beginning and end. An empty task is rejected.

The app creates an object with a unique ID, the text and `completed: false`. `tasks.unshift(newTask)` puts the newest item at the top. The app then saves tasks, renders the list, clears the input and focuses it again.

### G. Completing and deleting tasks

The app uses **event delegation**: instead of adding a separate listener to every checkbox and Delete button, one listener is added to their parent list.

When a checkbox changes, the app finds the parent task row, reads its `data-id`, then uses `find()` to locate that task object. Its `completed` property is updated from the checkbox's checked state. The data is saved and the display refreshed.

When Delete is clicked, `filter()` creates a new array containing all tasks except the one whose ID matches the clicked row. The new array is saved, and the list is rendered again.

### H. Filter buttons and data attributes

Buttons have attributes such as `data-filter="active"`. JavaScript reads the value with `button.dataset.filter`. When a filter is clicked, `currentFilter` changes, the `active` class is updated, the accessibility state `aria-pressed` is updated, and `renderTasks()` draws the matching list.

### I. Clear completed

The clear button uses `filter()` to keep only tasks that are not completed. It saves the new array and redraws the list. It also displays a message if there were no completed tasks to clear.

At the bottom of the script, `renderTasks()` runs once when the page opens. Because `tasks` was loaded near the top, saved tasks appear immediately.

## 6. Important terms

- **Event:** Something happening in the browser, such as a click or form submission.
- **Event listener:** Code that runs when a specified event happens.
- **Array:** An ordered collection. This app uses an array to keep all tasks.
- **Object:** A group of related properties, such as one task's ID, text and status.
- **Boolean:** A value of either `true` or `false`.
- **DOM:** The Document Object Model; the browser's representation of the webpage that JavaScript can change.
- **JSON:** A text format used to represent structured data.
- **localStorage:** Browser storage that keeps string key-value pairs for the website's origin.
- **CRUD:** Create, Read, Update and Delete. This app supports all four.
- **Responsive design:** Design that adapts to mobile, tablet and desktop screen sizes.

## 7. Likely viva questions and sample answers

**1. Explain your project.**  
“My project is a simple To-Do List application built with HTML, CSS and JavaScript. It lets users add tasks, mark them complete, delete tasks and filter the list. I use localStorage to retain tasks in the same browser after a refresh.”

**2. Why did you choose this project?**  
“It demonstrates forms, event listeners, arrays and objects, DOM manipulation, browser storage and responsive CSS.”

**3. What does HTML do?**  
“HTML creates the structure: input field, buttons, list and headings.”

**4. What does CSS do?**  
“CSS controls colours, spacing, button styles, task states and mobile layout.”

**5. What does JavaScript do?**  
“It manages task data, reacts to user actions, filters tasks, saves data and updates the visible list.”

**6. What is localStorage?**  
“It is browser storage that keeps string values for a website and can retain them after a refresh.”

**7. Is localStorage a database?**  
“No. It is client-side browser storage, not a server database, and it does not sync between devices.”

**8. Why use `JSON.stringify()`?**  
“localStorage stores strings, so stringify converts the task array to a string before saving it.”

**9. Why use `JSON.parse()`?**  
“It converts the stored JSON string back into a JavaScript value so the app can use the tasks again.”

**10. What is an array?**  
“An array is an ordered collection. Here it stores all task objects.”

**11. What is an object here?**  
“Each task is an object with an ID, task text and a completed Boolean.”

**12. Why have a task ID?**  
“The ID helps update or delete the correct task, even if two tasks have the same text.”

**13. What is DOM manipulation?**  
“It means creating or changing webpage elements using JavaScript.”

**14. Why use `addEventListener()`?**  
“To run code when the form is submitted, a checkbox changes, or a button is clicked.”

**15. Why use `preventDefault()`?**  
“To stop the browser's normal form submission so the app can handle it without reloading the page.”

**16. What is event delegation?**  
“It is attaching a listener to a parent element to handle events from child elements. I use it for checkboxes and Delete buttons.”

**17. What does `filter()` do?**  
“It creates a new array containing only the items that pass a condition. I use it for filters and deletion.”

**18. What does `find()` do?**  
“It returns the first item matching a condition. I use it to find the task being marked complete.”

**19. Difference between `let` and `const`?**  
“A `const` binding cannot be reassigned; a `let` binding can. I use `let` for the task array because it is reassigned after certain operations.”

**20. Why use `textContent`?**  
“It inserts plain text instead of parsing a string as HTML, making it appropriate for user-entered task names.”

**21. What is CRUD?**  
“Create, Read, Update and Delete—the four basic data operations. This app demonstrates all four.”

**22. Does the app need internet?**  
“Once the files are opened, the basic task functions need no external API. Tasks are stored locally in the browser.”

**23. What are its limitations?**  
“Tasks are stored only in the current browser. There are no user accounts, server backup or device synchronisation.”

**24. How would you improve it?**  
“I could add due dates, priorities, categories, search, user accounts, a backend and automated tests.”

**25. Is it full-stack?**  
“No. This version is a frontend project without its own backend or database.”

## 8. Speaking script for your teacher

“Good morning. My project is a simple To-Do List web application made using HTML, CSS and JavaScript. It helps users organise work by adding tasks, marking tasks completed, deleting tasks and filtering the list.

HTML provides the structure, CSS controls the design and responsive layout, and JavaScript manages the task array and user interactions. I use localStorage to save the task list in the browser. The app converts the array to a JSON string when saving and parses it again when loading.

I use DOM manipulation to display task rows dynamically and event listeners to respond to form submissions, checkbox changes and button clicks. One limitation is that tasks are saved only in the current browser, not in a cloud database. This project helped me understand arrays, objects, events, DOM manipulation and browser storage.”

## 9. Final demo checklist

- Add two or three tasks.
- Mark one complete.
- Show All, Active and Completed.
- Refresh and demonstrate that the list persists.
- Delete one task.
- Clear completed tasks.
- Explain why the app updates the `tasks` array, runs `saveTasks()`, and then calls `renderTasks()`.
